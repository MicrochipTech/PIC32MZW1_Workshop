/*******************************************************************************
  MPLAB Harmony Application Source File

  Company:
    Microchip Technology Inc.

  File Name:
    app_motor.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It
    implements the logic of the application's state machine and it may call
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include "app_motor.h"
#include "peripheral/spi/spi_master/plib_spi2_master.h"
#include "peripheral/gpio/plib_gpio.h"

#include "app_control.h"
#include "mqtt_app.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_MOTOR_Initialize function.

    Application strings and buffers are be defined outside this structure.
*/

APP_MOTOR_DATA app_motorData;
uint16_t i, j ;
// counterclockwise
const uint8_t stepperCCW[8] = {0x80, 0x3C, 0x00, 0x3C, 0x40, 0x3C, 0xC0, 0x3C} ;
// clockwise
const uint8_t stepperCW[8] = {0xC0, 0x3C, 0x40, 0x3C, 0x00, 0x3C, 0x80, 0x3C} ;
uint16_t app_motorTaskDelay ;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
*/

void SPIEventHandler(uintptr_t context )
{
    app_motorData.isSPITransferDone = true ;
    /* De-assert the CS line */
    if (app_motorData.isSPIDeassertCSline)
        MOTOR_CS_PIN_Set() ;
}

void MotorSwitchEventHandler(GPIO_PIN pin, uintptr_t context)
{
    if (pin == MOTOR_UPPER_SWITCH_PIN)
    {
        if ((MOTOR_UPPER_SWITCH_Get() == 0) && (!app_motorData.switchDetected))
        {
            app_motorData.switchDetected = true ;
            app_motorData.motorStatus = MOTOR_STOP ;
            app_motorData.motorDirection = MOTOR_COUNTERCLOCKWISE ;
            app_motorData.state = APP_MOTOR_STATE_INIT_IODIR_REG ;
        }
    }
    else if (pin == MOTOR_BOTTOM_SWITCH_PIN)
    {
        if ((MOTOR_BOTTOM_SWITCH_Get() == 0) && (app_motorData.switchDetected))
        {
            app_motorData.switchDetected = false ;
            app_motorData.motorStatus = MOTOR_STOP ;
            app_motorData.motorDirection = MOTOR_CLOCKWISE ;
            app_motorData.state = APP_MOTOR_STATE_INIT_IODIR_REG ;
        }
    }
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


/* TODO:  Add any necessary local functions.
*/



// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_MOTOR_Initialize ( void )

  Remarks:
    See prototype in app_motor.h.
 */

void APP_MOTOR_Initialize ( void )
{
    /* Place the App state machine in its initial state. */
    app_motorData.state = APP_MOTOR_STATE_INIT;

    /* TODO: Initialize your application's state machine and other
     * parameters.
     */
    app_motorTaskDelay = 100 ;    
    app_motorData.isSPITransferDone = false ;
    app_motorData.isSPIDeassertCSline = true ;
    app_motorData.motorStatus = MOTOR_STOP ;
    /* check the initial state of the switches */
    if (MOTOR_UPPER_SWITCH_Get() == 0)
    {
        app_motorData.motorDirection = MOTOR_COUNTERCLOCKWISE ;
        app_motorData.switchDetected = true ;
    }
    else if (MOTOR_BOTTOM_SWITCH_Get() == 0)
    {
        app_motorData.motorDirection = MOTOR_CLOCKWISE ;
        app_motorData.switchDetected = false ;
    }
}

/******************************************************************************
  Function:
    void APP_MOTOR_Tasks ( void )

  Remarks:
    See prototype in app_motor.h.
 */

void APP_MOTOR_Tasks ( void )
{

    /* Check the application's current state. */
    switch ( app_motorData.state )
    {
        /* Application's initial state. */
        case APP_MOTOR_STATE_INIT:
        {
            SYS_CONSOLE_PRINT("[APP_MOTOR] Init.\r\n") ;
            MOTOR_CS_PIN_Set() ;
            SPI2_CallbackRegister(SPIEventHandler, (uintptr_t) 0) ;
            GPIO_PinInterruptCallbackRegister(MOTOR_UPPER_SWITCH_PIN, MotorSwitchEventHandler, 0) ;
            GPIO_PinInterruptEnable(MOTOR_UPPER_SWITCH_PIN) ;
            GPIO_PinInputEnable(MOTOR_UPPER_SWITCH_PIN) ;
            
            GPIO_PinInterruptCallbackRegister(MOTOR_BOTTOM_SWITCH_PIN, MotorSwitchEventHandler, 0) ;
            GPIO_PinInterruptEnable(MOTOR_BOTTOM_SWITCH_PIN) ;
            GPIO_PinInputEnable(MOTOR_BOTTOM_SWITCH_PIN) ;
            
            app_motorData.state = APP_MOTOR_STATE_SET_RESET ;
            break ;
        }
        case APP_MOTOR_STATE_SET_RESET:
        {
            MOTOR_RESET_PIN_Clear() ;
            app_motorData.state = APP_MOTOR_STATE_RELEASE_RESET ;
            break ;
        }
        case APP_MOTOR_STATE_RELEASE_RESET:
        {
            MOTOR_RESET_PIN_Set() ;
            app_motorData.state = APP_MOTOR_STATE_INIT_IODIR_REG ;
            break ;
        }
        case APP_MOTOR_STATE_INIT_IODIR_REG:
        {
            /* fill SPI payload */
            app_motorData.txData[0] = MCP_ADDR ;
            app_motorData.txData[1] = MCP_IODIR ;
            app_motorData.txData[2] = 0xFF ; // set all inputs, de-energized motor
            /* engage SPI transaction */
            MOTOR_CS_PIN_Clear() ;
            app_motorData.isSPIDeassertCSline = true ;
            app_motorData.state = APP_MOTOR_STATE_TRANSFER_COMPLETE_WAIT ;
            app_motorData.nextState = APP_MOTOR_STATE_INIT_INT_REG ;
            if (!SPI2_WriteRead(app_motorData.txData, 3, NULL, 0))
                app_motorData.state = APP_MOTOR_STATE_ERROR ;
            break ;
        }
        case APP_MOTOR_STATE_INIT_INT_REG:
        {
            /* fill SPI payload */
            app_motorData.txData[0] = MCP_ADDR ;
            app_motorData.txData[1] = MCP_GPINTEN ;
            app_motorData.txData[2] = 0x00 ;    // no interrupt
            /* engage SPI transaction */
            MOTOR_CS_PIN_Clear() ;
            app_motorData.isSPIDeassertCSline = true ;
            app_motorData.state = APP_MOTOR_STATE_TRANSFER_COMPLETE_WAIT ;
            app_motorData.nextState = APP_MOTOR_STATE_READ_COMMAND ;
            if (!SPI2_WriteRead(app_motorData.txData, 3, NULL, 0))
                app_motorData.state = APP_MOTOR_STATE_ERROR ;
            break ;
        }
        case APP_MOTOR_STATE_READ_COMMAND:
        {
            /* fill SPI payload */
            app_motorData.txData[0] = MCP_ADDR | 1 ;
            app_motorData.txData[1] = MCP_IODIR ;   // register to read
            /* engage SPI transaction */
            MOTOR_CS_PIN_Clear() ;
            app_motorData.isSPIDeassertCSline = false ;
            app_motorData.state = APP_MOTOR_STATE_TRANSFER_COMPLETE_WAIT ;
            app_motorData.nextState = APP_MOTOR_STATE_READ_DATA ;
            if (!SPI2_WriteRead(app_motorData.txData, 2, NULL, 0))
                app_motorData.state = APP_MOTOR_STATE_ERROR ;
            break ;
        }
        case APP_MOTOR_STATE_READ_DATA:
        {
            app_motorData.isSPIDeassertCSline = true ;
            app_motorData.state = APP_MOTOR_STATE_TRANSFER_COMPLETE_WAIT ;
            app_motorData.nextState = APP_MOTOR_STATE_PRINT_DATA ;
            if (!SPI2_WriteRead(NULL, 0, app_motorData.rxData, 1))
                app_motorData.state = APP_MOTOR_STATE_ERROR ;
            break ;
        }
        case APP_MOTOR_STATE_PRINT_DATA:
        {
            SYS_CONSOLE_PRINT("[APP_MOTOR] Read: %02x\r\n", app_motorData.rxData[0]) ;
            app_motorData.state = APP_MOTOR_STATE_PREPARE_ROTATION ;
            break ;
        }
        case APP_MOTOR_STATE_TRANSFER_COMPLETE_WAIT:
        {
            if (app_motorData.isSPITransferDone == true)
            {
                app_motorData.isSPITransferDone = false ;
                app_motorData.state = app_motorData.nextState ;
            }
            break ;
        }
        case APP_MOTOR_STATE_PREPARE_ROTATION:
        {
            if (app_controlData.switchData.switchStatus == true && app_motorData.motorStatus == MOTOR_STOP)
            {
                SYS_CONSOLE_PRINT("[APP MOTOR] Button pressed\r\n") ;
                app_motorData.motorStatus = MOTOR_RUN ;
            }
            if (mqtt_appData.toggleFlag == true && app_motorData.motorStatus == MOTOR_STOP)
            {
                mqtt_appData.toggleFlag = false ;
                if (mqtt_appData.toggleValue)
                {
                    SYS_CONSOLE_PRINT("[APP MOTOR] Open requested\r\n") ;
                    if (MOTOR_UPPER_SWITCH_Get() == 0)
                    {
                        SYS_CONSOLE_PRINT("[APP MOTOR] Already open, do nothing\r\n") ;
                        app_motorData.motorDirection = MOTOR_COUNTERCLOCKWISE ;
                        app_motorData.switchDetected = true ;
                    }
                    else
                    {
                        app_motorData.motorStatus = MOTOR_RUN ;
                    }
                }
                else
                {
                    SYS_CONSOLE_PRINT("[APP MOTOR] Close requested\r\n") ;
                    if (MOTOR_BOTTOM_SWITCH_Get() == 0)
                    {
                        SYS_CONSOLE_PRINT("[APP MOTOR] Already close, do nothing\r\n") ;
                        app_motorData.motorDirection = MOTOR_CLOCKWISE ;
                        app_motorData.switchDetected = false ;
                    }
                    else
                    {
                        app_motorData.motorStatus = MOTOR_RUN ;
                    }
                }
            }
            if (app_motorData.motorStatus == MOTOR_RUN)
            {
                i = 0, j = 0 ;
                // first, set pins as output to control motor
                app_motorData.state = APP_MOTOR_STATE_SET_IODIR_REG ;
                app_motorTaskDelay = 5 ;
            }
            break ;
        }
        case APP_MOTOR_STATE_SET_IODIR_REG:
        {
            /* fill SPI payload */
            app_motorData.txData[0] = MCP_ADDR ;
            app_motorData.txData[1] = MCP_IODIR ;
            app_motorData.txData[2] = 0x00 ;    // set all outputs
            /* engage SPI transaction */
            MOTOR_CS_PIN_Clear() ;
            app_motorData.isSPIDeassertCSline = true ;
            app_motorData.state = APP_MOTOR_STATE_TRANSFER_COMPLETE_WAIT ;
            app_motorData.nextState = APP_MOTOR_STATE_START_ROTATION ;
            if (!SPI2_WriteRead(app_motorData.txData, 3, NULL, 0))
                app_motorData.state = APP_MOTOR_STATE_ERROR ;
            break ;
        }
        case APP_MOTOR_STATE_START_ROTATION:
        {
            /* fill SPI payload */            
            app_motorData.txData[0] = MCP_ADDR ;
            app_motorData.txData[1] = MCP_GPIO ;
            if (app_motorData.motorDirection == MOTOR_CLOCKWISE)
                app_motorData.txData[2] = stepperCW[j] ;
            else if (app_motorData.motorDirection == MOTOR_COUNTERCLOCKWISE)
                app_motorData.txData[2] = stepperCCW[j] ;
            /* engage SPI transaction */            
            MOTOR_CS_PIN_Clear() ;
            app_motorData.isSPIDeassertCSline = true ;
            app_motorData.state = APP_MOTOR_STATE_TRANSFER_COMPLETE_WAIT ;
            i++, j++ ;
            if (j == 8)     j = 0 ;
            // with the help of upper and bottom switches, not supposed to reach the next state
            // upper and bottom switches will help to stop motor rotation
            if (i == 5000)  app_motorData.nextState = APP_MOTOR_STATE_STOP_ROTATION_1 ;
            else            app_motorData.nextState = APP_MOTOR_STATE_START_ROTATION ;
            if (!SPI2_WriteRead(app_motorData.txData, 3, NULL, 0))
                app_motorData.state = APP_MOTOR_STATE_ERROR ;
            break ;
        }
        case APP_MOTOR_STATE_STOP_ROTATION_1:
        {
            if (app_motorData.motorDirection == MOTOR_CLOCKWISE)
                app_motorData.txData[2] = 0xC0 ;
            else if (app_motorData.motorDirection == MOTOR_COUNTERCLOCKWISE)
                app_motorData.txData[2] = 0x80 ;
            MOTOR_CS_PIN_Clear() ;
            app_motorData.isSPIDeassertCSline = true ;
            app_motorData.state = APP_MOTOR_STATE_TRANSFER_COMPLETE_WAIT ;
            app_motorData.nextState = APP_MOTOR_STATE_STOP_ROTATION_2 ;
            if (!SPI2_WriteRead(app_motorData.txData, 3, NULL, 0))
                app_motorData.state = APP_MOTOR_STATE_ERROR ;
            break ;
        }
        case APP_MOTOR_STATE_STOP_ROTATION_2:
        {
            app_motorData.txData[2] = 0x3C ;
            MOTOR_CS_PIN_Clear() ;
            app_motorData.isSPIDeassertCSline = true ;
            app_motorData.state = APP_MOTOR_STATE_TRANSFER_COMPLETE_WAIT ;
            app_motorData.nextState = APP_MOTOR_STATE_INIT_IODIR_REG ;
            if (!SPI2_WriteRead(app_motorData.txData, 3, NULL, 0))
                app_motorData.state = APP_MOTOR_STATE_ERROR ;            
            break ;
        }
        case APP_MOTOR_STATE_ERROR:
        {
            // treat error
            break ;
        }
        /* The default state should never be executed. */
        default:
        {
            /* TODO: Handle error in application's state machine. */
            break;
        }
    }
    vTaskDelay(app_motorTaskDelay / portTICK_PERIOD_MS);    
}


/*******************************************************************************
 End of File
 */
