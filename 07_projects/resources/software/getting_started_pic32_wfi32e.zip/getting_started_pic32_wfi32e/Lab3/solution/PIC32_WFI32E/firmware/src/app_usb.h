/*******************************************************************************
  MPLAB Harmony Application Header File

  Company:
    Microchip Technology Inc.

  File Name:
    app_usb.h

  Summary:
    This header file provides prototypes and definitions for the application.

  Description:
    This header file provides function prototypes and data type definitions for
    the application.  Some of these are required by the system (such as the
    "APP_USB_Initialize" and "APP_USB_Tasks" prototypes) and some of them are only used
    internally by the application (such as the "APP_USB_STATES" definition).  Both
    are defined here for convenience.
*******************************************************************************/

#ifndef _APP_USB_H
#define _APP_USB_H

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "configuration.h"
#include "definitions.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

extern "C" {

#endif
// DOM-IGNORE-END

// *****************************************************************************
// *****************************************************************************
// Section: Definitions
// *****************************************************************************
// *****************************************************************************

#define APP_USB_QUEUE_SIZE       10
#define APP_USB_QUEUE_ITEM_SIZE  sizeof(char *)
#define APP_QUEUE_DELAY          (portTICK_PERIOD_MS * 1000)    
    
// *****************************************************************************
// *****************************************************************************
// Section: Types and structures
// *****************************************************************************
// *****************************************************************************
    
typedef enum
{
    APP_USB_STATE_NOT_READY,
    APP_USB_STATE_IDLE,
    APP_USB_STATE_PRINT,
    APP_USB_STATE_ERROR,

} APP_USB_STATES;

// *****************************************************************************

typedef struct
{
    APP_USB_STATES state;
    bool isQueueEmpty;
    char *strToPrint;
    
} APP_USB_DATA;

// *****************************************************************************
// *****************************************************************************
// Section: Global variables
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Routines
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

void APP_USB_Initialize ( void );
void APP_USB_Tasks( void );
BaseType_t APP_PRINT_STRING(char *str, bool isrFlag);

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif /* _APP_USB_H */

/*******************************************************************************
 End of File
 */

