/*******************************************************************************
  MPLAB Harmony Application Source File

  Company:
    Microchip Technology Inc.

  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It
    implements the logic of the application's state machine and it may call
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 ******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include "app_sdcard.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

APP_SDCARD_DATA appSDcardData;
uint8_t try = 0;
QueueHandle_t SDcardQueueHandle;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* Callback that will be executed each time a SD card is plugged or removed from
 * it's slot on the IO1 Xplained pro board */
void APP_SDCARD_DETECT_EventHandler(GPIO_PIN pin, uintptr_t context)
{
    if(pin == GPIO_PIN_RB2)
    {
        /* level high thru the Pull up -> there is no SD card in the slot */
        if(GPIO_RB2_Get())
        {
            appSDcardData.isThereSDcard = false;
            
            // -- Optional
            /* If the application was running */
            if((appSDcardData.state != APP_SDCARD_STATE_IDLE) && 
               (appSDcardData.state != APP_SDCARD_STATE_ERROR))
            {
                /* Print error */
                APP_PRINT_STRING("SD card ejected while operating -> "
                                       "data might be corrupted or lost", true);
                appSDcardData.state = APP_SDCARD_STATE_ERROR;
            }
        }
        /* level low -> there is a SD card in the slot */
        else
        {
            appSDcardData.isThereSDcard = true;
        }
    }
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

/* Application function that fill the queue with temperature value */
bool APP_SDCARD_Notify(float temperature)
{
    /* Verify that the queue exists */
    if(SDcardQueueHandle != NULL)
    {        
        /* TODO -----> Step #2 */
        if(xQueueOverwrite(SDcardQueueHandle, &temperature) == pdTRUE)
        {
            return true;
        }
    }
    
    return false;
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_SDCARD_Initialize ( void )
{
    struct tm sys_time;
    
    /* Setup RTC */
    sys_time.tm_hour  = BUILD_TIME_HOUR;
    sys_time.tm_min   = BUILD_TIME_MIN;
    sys_time.tm_sec   = BUILD_TIME_SEC;
    
    RTCC_TimeSet(&sys_time);
    
    /* Register callback for SD card detect feature */
    GPIO_PinInterruptCallbackRegister(
            GPIO_PIN_RB2, 
            APP_SDCARD_DETECT_EventHandler,
            0);
    GPIO_PinInterruptEnable(GPIO_PIN_RB2);
    
    /* Initialize SD card detect flag */
    appSDcardData.isThereSDcard = !(GPIO_RB2_Get() == 1);
    
    /* TODO -----> Step #1 */
    SDcardQueueHandle = xQueueCreate(APP_SDCARD_QUEUE_SIZE, 
            APP_SDCARD_QUEUE_ITEM_SIZE);
    
    /* Go to idle state */
    appSDcardData.state = APP_SDCARD_STATE_IDLE;
}

//******************************************************************************

void APP_SDCARD_Tasks ( void )
{    
    struct tm sys_time;
    char log_data[LOG_LEN];
    char fname[SYS_FS_FILE_NAME_LEN];
    char stmp[256];
    
    switch ( appSDcardData.state )
    {
        case APP_SDCARD_STATE_IDLE:
            /* Step #3 Already Implemented */
            /* Wait for log queue filling */
            if(uxQueueMessagesWaiting(SDcardQueueHandle) != 0)
            {
                /* Read from message queue */
                if(xQueueReceive(SDcardQueueHandle, &
                        appSDcardData.temperature, 
                        APP_QUEUE_DELAY) == pdTRUE)
                {
                    /* If it succeed to read go to SD card log procedure */
                    appSDcardData.state = APP_SDCARD_STATE_MOUNT;
                }
                else
                {
                    /* If it fail to read go to error */
                    appSDcardData.state = APP_SDCARD_STATE_ERROR;
                }
            }
            break;
        
        case APP_SDCARD_STATE_MOUNT:
            /* Verify that there is a SD card in the slot */
            if(appSDcardData.isThereSDcard)
            {
                /* Try APP_FS_MAX_TRY times to mount the SD Card */
                if((SYS_FS_Mount(APP_DEV_NAME, APP_MOUNT_NAME, FAT, 0, NULL) != 
                                 SYS_FS_RES_SUCCESS) && try ++ < APP_FS_MAX_TRY)
                {
                    appSDcardData.state = APP_SDCARD_STATE_MOUNT;
                }
                /* If it fails APP_FS_MAX_TRY time raise an error */
                else if(try >= APP_FS_MAX_TRY)
                {
                    try = 0;
                    
                    /* Error message */
                    sprintf(stmp, "Mounting error : %d\r\n", SYS_FS_Error());
                    APP_PRINT_STRING(stmp, false);                  
                    
                    /* Switch state */
                    appSDcardData.state = APP_SDCARD_STATE_ERROR;
                }
                /* SD card mounted */
                else
                {
                    try = 0;
                    
                    /* Set the address pointer to the mounted volume */
                    SYS_FS_CurrentDriveSet(APP_MOUNT_NAME);
                    
                    /* Create a folder (if it already exists it does nothing) */
                    SYS_FS_DirectoryMake(APP_DIR_NAME);
                    
                    /* Debug message */
                    APP_PRINT_STRING("SD card mounted\r\n", false);
                    
                    /* Switch state */
                    appSDcardData.state = APP_SDCARD_STATE_OPEN;
                }
            }
            /* If there is no SD card -> go to error */
            else
            {
                LED_GREEN_On();
                LED_RED_Off();
                
                /* Error message */
                APP_PRINT_STRING("There is no SD card\r\n", false);
                
                /* Switch state */
                appSDcardData.state = APP_SDCARD_STATE_ERROR;
            }
            break;
        
        case APP_SDCARD_STATE_OPEN:
            /* Try to open target file up to APP_FS_MAX_TRY times */
            sprintf(fname, "%s/%s", APP_DIR_NAME, APP_FILE_NAME);
            appSDcardData.FShandle = SYS_FS_FileOpen(fname, 
                    SYS_FS_FILE_OPEN_APPEND);
            
            if((appSDcardData.FShandle == SYS_FS_HANDLE_INVALID) && 
                    (try ++ < APP_FS_MAX_TRY))
            {
                appSDcardData.state = APP_SDCARD_STATE_OPEN;
            }
            /* If it fails APP_FS_MAX_TRY time raise an error */
            else if(try >= APP_FS_MAX_TRY)
            {
                try = 0;
                
                /* Error message */
                sprintf(stmp, "Opening error : %d\r\n", SYS_FS_Error());
                APP_PRINT_STRING(stmp, false);
                
                /* Switch state */
                appSDcardData.state = APP_SDCARD_STATE_ERROR;
            }
            /* File opened */
            else
            {
                try = 0;
                
                /* Error message */
                APP_PRINT_STRING("File open ...\r\n", false);
                
                /* Switch state */
                appSDcardData.state = APP_SDCARD_STATE_WRITE;
            }
            break;
            
        case APP_SDCARD_STATE_WRITE:
            /* Get current time */
            RTCC_TimeGet(&sys_time);
            
            /* Try to write in the SD card up to APP_FS_MAX_TRY times */
            sprintf(&log_data[0], "[%02d:%02d:%02d]", sys_time.tm_hour
                                                    , sys_time.tm_min
                                                    , sys_time.tm_sec);
            sprintf(&log_data[LOG_TIME_LEN], " Temperature : %.2f C\r\n", 
                    appSDcardData.temperature);
                
            if((SYS_FS_FileStringPut(appSDcardData.FShandle, log_data) != 
                    SYS_FS_RES_SUCCESS) && try ++ < APP_FS_MAX_TRY)
            {
                appSDcardData.state = APP_SDCARD_STATE_WRITE;
            }
            /* If it fails APP_FS_MAX_TRY time raise an error */
            else if(try >= APP_FS_MAX_TRY)
            {
                try = 0;
                
                /* Error message */
                sprintf(stmp, "Writing error : %d\r\n", SYS_FS_Error());
                APP_PRINT_STRING(stmp, false);
                
                /* Switch state */
                appSDcardData.state = APP_SDCARD_STATE_ERROR;
            }
            /* Log successful */
            else
            {
                try = 0;
                
                /* Debug message */
                APP_PRINT_STRING("Log done ...\r\n", false);
                
                /* Switch state */
                appSDcardData.state = APP_SDCARD_STATE_CLOSE;
            }
            break;

        case APP_SDCARD_STATE_CLOSE:
            /* Try to close target file up to APP_FS_MAX_TRY times */
            appSDcardData.FShandle = SYS_FS_FileClose(appSDcardData.FShandle);
            if(appSDcardData.FShandle != SYS_FS_RES_SUCCESS && 
                    try ++ < APP_FS_MAX_TRY)
            {
                appSDcardData.state = APP_SDCARD_STATE_CLOSE;
            }
            /* If it fails APP_FS_MAX_TRY time raise an error */
            else if(try >= APP_FS_MAX_TRY)
            {
                try = 0;
                
                /* Error message */
                sprintf(stmp, "Closing error : %d\r\n", SYS_FS_Error());
                APP_PRINT_STRING(stmp , false);
                
                /* Switch state */
                appSDcardData.state = APP_SDCARD_STATE_ERROR;
            }
            /* File closed */
            else
            {
                try = 0;
                
                /* Debug message */
                APP_PRINT_STRING("File closed ...\r\n", false);
                
                /* Switch state */
                appSDcardData.state = APP_SDCARD_STATE_UNMOUNT;
            }
            break;
        
        case APP_SDCARD_STATE_UNMOUNT:
            /* Try to unmount the SD card up to APP_FS_MAX_TRY times */
            if((SYS_FS_Unmount(APP_MOUNT_NAME) != SYS_FS_RES_SUCCESS) && 
                    try ++ < APP_FS_MAX_TRY)
            {
                appSDcardData.state = APP_SDCARD_STATE_UNMOUNT;
            }
            /* If it fails APP_FS_MAX_TRY time raise an error */
            else if(try >= APP_FS_MAX_TRY)
            {
                try = 0;
                
                /* Error message */
                sprintf(stmp, "Unmounting error : %d\r\n", SYS_FS_Error());
                APP_PRINT_STRING(stmp, false);
                
                /* Switch state */
                appSDcardData.state = APP_SDCARD_STATE_ERROR;
            }
            /* SD card unmount */
            else
            {
                try = 0;
                
                LED_GREEN_On();
                LED_RED_Off();
                
                /* Debug message */
                APP_PRINT_STRING("Free to remove SD card\r\n", false);
                
                /* Switch state */
                appSDcardData.state = APP_SDCARD_STATE_IDLE;
            }
            break;
        
        case APP_SDCARD_STATE_ERROR:
            LED_RED_Off();
            LED_GREEN_Off();
            
        default:
            break;
    }
}


/*******************************************************************************
 End of File
 */