/*******************************************************************************
  MPLAB Harmony Application Source File

  Company:
    Microchip Technology Inc.

  File Name:
    app_usb.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It
    implements the logic of the application's state machine and it may call
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include "app_usb.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************
QueueHandle_t USBQueueHandle;
APP_USB_DATA appUsbData;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

/* Application function that fill the queue with the string to print
 * isrFlag must be true if you are calling the function from an interrupt */
BaseType_t APP_PRINT_STRING(char *str, bool isrFlag)
{
    BaseType_t errCode = pdFALSE;
    
    /* Verify that the queue exists */
    if(USBQueueHandle != NULL)
    {        
        /* TODO -----> Step #4b */
        if (isrFlag)
        {
            /* pdFALSE because USB task does not have an higher priority
             * than the other tasks which can call this function */
            errCode = xQueueSendToBackFromISR(USBQueueHandle, &str , pdFALSE);            
        }
        else
        {
            errCode = xQueueSendToBack(USBQueueHandle, &str , APP_QUEUE_DELAY);
        }
    }
    return errCode;
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

void APP_USB_Initialize ( void )
{
    /* TODO -----> Step #4a */
    USBQueueHandle = xQueueCreate(APP_USB_QUEUE_SIZE, 
            APP_USB_QUEUE_ITEM_SIZE);
    
    appUsbData.state = APP_USB_STATE_NOT_READY;
    
    /* Notify the user that the application is not ready to print anything */
    LED_RED_On();
}

// *****************************************************************************

void APP_USB_Tasks ( void )
{
    /* Check the application's current state. */
    switch ( appUsbData.state )
    {
        case APP_USB_STATE_NOT_READY:
            /* Wait for the console ready */
            if (SYS_DEBUG_Status(SYS_CONSOLE_INDEX_0) == SYS_STATUS_READY)
            {
                /* Notify the user that the application is ready to print */
                LED_RED_Off();
                LED_GREEN_On();
                
                /* Switch state */
                appUsbData.state = APP_USB_STATE_IDLE;
            }
            break;
            
        case APP_USB_STATE_IDLE:
            /* Wait for log queue filling */
            if(uxQueueMessagesWaiting(USBQueueHandle) != 0)
            {
                /* Read from message queue */
                if(xQueueReceive(USBQueueHandle, &appUsbData.strToPrint, 
                                                     APP_QUEUE_DELAY) == pdTRUE)
                {
                    /* If it succeed go to print task */
                    appUsbData.state = APP_USB_STATE_PRINT;
                }
                else
                {
                    /* If it fails to read go to error */
                    appUsbData.state = APP_USB_STATE_ERROR;   
                }
            }
            break;

        case APP_USB_STATE_PRINT:
            /* TODO -----> Step #5 */
            SYS_DEBUG_MESSAGE(SYS_ERROR_DEBUG, appUsbData.strToPrint);
            
            /* Switch back to idle state */
            appUsbData.state = APP_USB_STATE_IDLE;
            break;
            
        case APP_USB_STATE_ERROR:
            LED_RED_Off() ;
            LED_GREEN_Off() ;
            break;
            
        default:
            break;
    }
}


/*******************************************************************************
 End of File
 */
