/*******************************************************************************
* Copyright (C) 2020 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/

/*******************************************************************************
  MPLAB Harmony Application Source File

  Company:
    Microchip Technology Inc.

  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It
    implements the logic of the application's state machine and it may call
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 ******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include "app_sensor.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

APP_SENSOR_DATA             appSensorData;
DRV_I2C_TRANSFER_HANDLE     i2c1TransferHandle;
SYS_TIME_HANDLE             timeHandle;
uint16_t                    tmp;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* Callback that will be executed each time the timer expire */
static void SYS_TIME_EventHandler(uintptr_t context)
{
    if(appSensorData.isLogEnable)
    {
        LED_RED_On();
        LED_GREEN_Off();
        appSensorData.tmrExpired = true;
    }
}

// *****************************************************************************

/* Callback that will be executed each time the switch 1 is pressed */
static void APP_SWITCH_EventHandler(GPIO_PIN pin, uintptr_t context)
{
    if (SWITCH1_Get() == SWITCH1_STATE_PRESSED)
    {
        appSensorData.isLogEnable = !appSensorData.isLogEnable; 
    }
}

// *****************************************************************************

/* Callback that will be executed each time an I2C transfer is finished */
static void APP_I2C_EventHandler(
    DRV_I2C_TRANSFER_EVENT event,
    DRV_I2C_TRANSFER_HANDLE transferHandle,
    uintptr_t context
)
{
    switch(event)
    {
        case DRV_I2C_TRANSFER_EVENT_COMPLETE:
            appSensorData.state = APP_SENSOR_STATE_USB_PRINT;
            break;

        case DRV_I2C_TRANSFER_EVENT_ERROR:
            /* Report error */ 
            APP_PRINT_STRING("I2C transfer event error\r\n", true);
            
            /* Disable temperature feature mode */
            appSensorData.state = APP_SENSOR_STATE_ERROR;
            break;

        default:
            break;
    }
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

/* Application function that will read the temperature from the I2C sensor */
DRV_I2C_ERROR APP_I2C_TEMP_READ(APP_SENSOR_DATA app_Data)
{
    DRV_I2C_ERROR error;
    uint8_t try = 0;
    
    do {
    DRV_I2C_ReadTransferAdd(appSensorData.i2c.instance, 
                            appSensorData.i2c.sensor.address,
                    (void *)appSensorData.i2c.i2cRxBuffer, 2, 
                          &(appSensorData.i2c.i2cTransferHandle));
            
    error = DRV_I2C_ErrorGet(appSensorData.i2c.i2cTransferHandle);
   
    } while((error != DRV_I2C_ERROR_NONE) && (++try <= 3));
    
    return error;
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

void APP_SENSOR_Initialize ( void )
{    
    /* Switch callback register */
    GPIO_PinInterruptCallbackRegister(GPIO_PIN_RA10, APP_SWITCH_EventHandler, 0);
    GPIO_PinInterruptEnable(GPIO_PIN_RA10) ;
    
    /* App data init */
    appSensorData.i2c.sensor.address = (TEMP_SENSOR_BASE_ADDRESS << 3) |
                                       (I2C1_A2_PULL << 2)             |
                                       (I2C1_A1_PULL << 1)             |
                                        I2C1_A0_PULL                   ;
    appSensorData.i2c.sensor.temp_reg     = TEMP_SENSOR_READ_TEMP_REG;
    appSensorData.i2c.sensor.config_reg   = TEMP_SENSOR_CONFIG_REG;
    appSensorData.i2c.i2cTransferHandle   = i2c1TransferHandle;
    appSensorData.i2c.instance            = DRV_I2C_Open(DRV_I2C_INDEX_0, 
                                                       DRV_IO_INTENT_READWRITE);
   
    /* I2C callback set */
    DRV_I2C_TransferEventHandlerSet(appSensorData.i2c.instance, 
            APP_I2C_EventHandler, 0);
    
    /* Timer expire callback set */
    SYS_TIME_CallbackRegisterMS(SYS_TIME_EventHandler, (uintptr_t)NULL, 5000, 
            SYS_TIME_PERIODIC);
    
    appSensorData.state = APP_SENSOR_STATE_IDLE;
}

// *****************************************************************************

void APP_SENSOR_Tasks ( void )
{
    char stmp[256];
    
    switch ( appSensorData.state )
    {
        case APP_SENSOR_STATE_IDLE:
            /* Wait for timer expire (5 second) */
            if(appSensorData.tmrExpired)
            {
                /* Reset timer flag */
                appSensorData.tmrExpired = false;
                
                /* Switch to app tasks */
                appSensorData.state = APP_SENSOR_STATE_I2C_READ_TASKS;
            }
            break ;
            
        case APP_SENSOR_STATE_I2C_READ_TASKS:
            /* Read temperature */
            if(APP_I2C_TEMP_READ(appSensorData) != DRV_I2C_ERROR_NONE)
            {
                /* Report error */ 
                APP_PRINT_STRING("I2C transfer error\r\n", false);
            
                /* Switch to error */
                appSensorData.state = APP_SENSOR_STATE_ERROR;
            }
            else
            {
                /* Switch to idle */
                appSensorData.state = APP_SENSOR_STATE_IDLE;
            }
            break ;
            
        case APP_SENSOR_STATE_USB_PRINT :
            /* Convert and store temperature */
            tmp = appSensorData.i2c.i2cRxBuffer[0] << 8 | 
                  appSensorData.i2c.i2cRxBuffer[1];
            
            appSensorData.i2c.lastValueRead = (tmp >> 7) * 0.5;
            
            /* Clean i2cRxBuffer */
            appSensorData.i2c.i2cRxBuffer[0] = 0;
            appSensorData.i2c.i2cRxBuffer[1] = 0;
            appSensorData.i2c.i2cRxBuffer[2] = 0;
            
            /* Print on CDC USB */
            sprintf(stmp, "Temperature : %f C\r\n", 
                                               appSensorData.i2c.lastValueRead);
            APP_PRINT_STRING(stmp, false);
            
            /* Log data into SD card */
            APP_SDCARD_Notify(appSensorData.i2c.lastValueRead);

            appSensorData.state = APP_SENSOR_STATE_IDLE;
              
            break;
            
        case APP_SENSOR_STATE_ERROR:
            LED_RED_Off() ;
            LED_GREEN_Off() ;
        default:
            break;

    }
}

/*******************************************************************************
 End of File
 */
