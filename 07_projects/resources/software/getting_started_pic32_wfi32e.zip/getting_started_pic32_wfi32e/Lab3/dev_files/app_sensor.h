/*******************************************************************************
  MPLAB Harmony Application Header File

  Company:
    Microchip Technology Inc.

  File Name:
    app_sensor.h

  Summary:
    This header file provides prototypes and definitions for the application.

  Description:
    This header file provides function prototypes and data type definitions for
    the application.  Some of these are required by the system (such as the
    "APP_SENSOR_Initialize" and "APP_SENSOR_Tasks" prototypes) and some of them are only used
    internally by the application (such as the "APP_SENSOR_STATES" definition).  Both
    are defined here for convenience.
*******************************************************************************/

#ifndef _APP_SENSOR_H
#define _APP_SENSOR_H

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "configuration.h"
#include "definitions.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

extern "C" {

#endif
// DOM-IGNORE-END

// *****************************************************************************
// *****************************************************************************
// Section: Definitions
// *****************************************************************************
// *****************************************************************************    
    
#define TEMP_SENSOR_READ_TEMP_REG   0x00
#define TEMP_SENSOR_CONFIG_REG      0x01

#define TEMP_SENSOR_BASE_ADDRESS    0x09
#define I2C1_A0_PULL                UP
#define I2C1_A1_PULL                UP
#define I2C1_A2_PULL                UP

// *****************************************************************************
// *****************************************************************************
// Section: Types and structures
// *****************************************************************************
// *****************************************************************************

typedef enum
{
    DOWN = 0,
    UP = 1,
} PULL;

// *****************************************************************************

typedef enum
{
    APP_SENSOR_STATE_WAIT_USB_CONSOLE_CONFIGURED = 0,
    APP_SENSOR_STATE_GET_CONSOLE_HANDLE,
    APP_SENSOR_STATE_IDLE,
    APP_SENSOR_STATE_I2C_READ_TASKS,
    APP_SENSOR_STATE_USB_PRINT,
    APP_SENSOR_STATE_ERROR,
} APP_SENSOR_STATES;


// *****************************************************************************

typedef struct
{
    uint16_t address;
    uint8_t id;
    uint8_t temp_reg;
    uint8_t config_reg;
    
} APP_I2C_TEMP_SENSOR_INFO;

// *****************************************************************************

typedef struct
{
    float                       lastValueRead;
    APP_I2C_TEMP_SENSOR_INFO    sensor;
    DRV_HANDLE                  instance;
    uint8_t                     i2cRxBuffer[3];    
    uint8_t                     i2cTxBuffer[3];
    DRV_I2C_TRANSFER_HANDLE     i2cTransferHandle;

} APP_I2C_TEMP_SENSOR_DATA;

// *****************************************************************************

typedef struct
{
    bool                        tmrExpired;
    bool                        isTransferDone;
    bool                        isLogEnable;
    APP_SENSOR_STATES           state;
    APP_I2C_TEMP_SENSOR_DATA    i2c;
    SYS_CONSOLE_HANDLE          console0Handle;
    
} APP_SENSOR_DATA;

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

void APP_SENSOR_Initialize ( void );

void APP_SENSOR_Tasks( void );

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif /* _APP_SENSOR_H */

/*******************************************************************************
 End of File
 */

