/*******************************************************************************
  MPLAB Harmony Application Source File

  Company:
    Microchip Technology Inc.

  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It
    implements the logic of the application's state machine and it may call
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 ******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include "app_sdcard.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

APP_SDCARD_DATA appSDcardData;
uint8_t try = 0;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

void APP_SDCARD_DETECT_EventHandler(GPIO_PIN pin, uintptr_t context)
{
    /* TODO -----> Step #4 */
    if(pin == GPIO_PIN_RB2)
    {
        /* level high thru the Pull up -> there is no SD card in the slot */
        if(GPIO_RB2_Get())
        {
            appSDcardData.isThereSDcard = false;
            
            // -- Optional
            /* If the application was running */
            if((appSDcardData.state != APP_SDCARD_STATE_IDLE) && 
               (appSDcardData.state != APP_SDCARD_STATE_ERROR))
            {
                SYS_DEBUG_MESSAGE(SYS_ERROR_DEBUG, 
          "SD card ejected while operating -> data might be corrupted or lost");

                appSDcardData.state = APP_SDCARD_STATE_ERROR;
            }            
        }
        /* level low -> there is a SD card in the slot */
        else
        {
            appSDcardData.isThereSDcard = true;
        }
    }
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

void APP_SDCARD_Notify(float temperature)
{
    /* TODO -----> Step #1 */
    appSDcardData.temperature = temperature;
    appSDcardData.isTemperatureReady = true;
}

static inline void APP_BuildLogString(char *log, struct tm time, float temperature)
{
    sprintf(&log[0], "[%02d:%02d:%02d]", time.tm_hour, time.tm_min, time.tm_sec);
    sprintf(&log[LOG_TIME_LEN], " Temperature : %.2f C\r\n", temperature);
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_SDCARD_Initialize ( void )
{
    struct tm sys_time;
    
    /* TODO -----> Step #2a */
	sys_time.tm_hour = BUILD_TIME_HOUR;
	/* TODO -----> Step #2b */
	sys_time.tm_min = BUILD_TIME_MIN;
	/* TODO -----> Step #2c */
	sys_time.tm_sec = BUILD_TIME_SEC;
	/* TODO -----> Step #2d */
    RTCC_TimeSet(&sys_time);
    /* TODO -----> Step #3a */
    GPIO_PinInterruptCallbackRegister(
            GPIO_PIN_RB2, 
            APP_SDCARD_DETECT_EventHandler,
            0);
    /* TODO -----> Step #3b */
    GPIO_PinInterruptEnable(GPIO_PIN_RB2);
    /* TODO -----> Step #5 */
    appSDcardData.isThereSDcard = !(GPIO_RB2_Get() == 1);
    /* End of configuration jump in to the first state of your state machine */
    appSDcardData.state = APP_SDCARD_STATE_IDLE;
}


/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_SDCARD_Tasks ( void )
{    
    struct tm sys_time;
    char log_data[LOG_LEN];
    
    /* Check the application's current state. */
    switch ( appSDcardData.state )
    {
        case APP_SDCARD_STATE_IDLE:
            /* TODO -----> Step #6 */
            if(appSDcardData.isTemperatureReady)
            {
                appSDcardData.isTemperatureReady = false;
                LED_RED_Off();
                appSDcardData.state = APP_SDCARD_STATE_MOUNT;
            }
            break;
        
        case APP_SDCARD_STATE_MOUNT:
            /* TODO -----> Step #7 */
            /* Verify that there is a SD card in the slot */
            if(appSDcardData.isThereSDcard)
            {
                /* Try 10 times to mount the SD Card */
                if((SYS_FS_Mount(APP_DEV_NAME, APP_MOUNT_NAME, FAT, 0, NULL) != SYS_FS_RES_SUCCESS) && try ++ < 10)
                {
                    appSDcardData.state = APP_SDCARD_STATE_MOUNT;
                }
                /* If it fails 10 time raise an error */
                else if(try >= 10)
                {
                    SYS_DEBUG_PRINT(SYS_ERROR_DEBUG, "Mounting error : %d\r\n", 
                            SYS_FS_Error());
                    try = 0;
                    appSDcardData.state = APP_SDCARD_STATE_ERROR;
                }
                /* SD card mounted */
                else
                {
                    try = 0;
                    /* Set the drive */
                    SYS_FS_CurrentDriveSet(APP_MOUNT_NAME);
                    /* Create directory */
                    SYS_FS_DirectoryMake(APP_DIR_NAME);
                    SYS_DEBUG_MESSAGE(SYS_ERROR_DEBUG, "Log in process ...\r\n");
                    LED_GREEN_On();
                    appSDcardData.state = APP_SDCARD_STATE_OPEN;
                }
            }
            /* If there is no SD card -> back to idle */
            else
            {
                SYS_DEBUG_MESSAGE(SYS_ERROR_DEBUG, "There is no SD card\r\n");
                LED_RED_On();
                appSDcardData.state = APP_SDCARD_STATE_IDLE;
            }
            break;
        
        case APP_SDCARD_STATE_OPEN:
            /* TODO -----> Step #8 */
            /* Try 10 times to open target file */
            appSDcardData.FShandle = SYS_FS_FileOpen(APP_LOG_FILE_PATH, SYS_FS_FILE_OPEN_APPEND);
            if((appSDcardData.FShandle == SYS_FS_HANDLE_INVALID) && (try ++ < 10))
            {
                appSDcardData.state = APP_SDCARD_STATE_OPEN;
            }
            /* If it fails 10 time raise an error */
            else if(try >= 10)
            {
                SYS_DEBUG_PRINT(SYS_ERROR_DEBUG, "Opening error : %d\r\n", SYS_FS_Error());
                try = 0;
                appSDcardData.state = APP_SDCARD_STATE_ERROR;
            }
            /* File opened */
            else
            {
                try = 0;
                SYS_DEBUG_MESSAGE(SYS_ERROR_DEBUG, "File open ...\r\n");
                appSDcardData.state = APP_SDCARD_STATE_WRITE;
            }
            break;
            
        case APP_SDCARD_STATE_WRITE:
            /* TODO -----> Step #9a */
			RTCC_TimeGet(&sys_time);
            
			/* TODO -----> Step #9b */
            APP_BuildLogString(log_data, sys_time, appSDcardData.temperature);
            
            /* TODO -----> Step #9c */
            if((SYS_FS_FileStringPut(appSDcardData.FShandle, log_data) != 
                    SYS_FS_RES_SUCCESS) && try ++ < 10)
            {
                appSDcardData.state = APP_SDCARD_STATE_WRITE;
            }
            /* If it fails 10 time raise an error */
            else if(try >= 10)
            {
                SYS_DEBUG_PRINT(SYS_ERROR_DEBUG, 
                        "Writing error : %d\r\n", SYS_FS_Error());
                try = 0;
                appSDcardData.state = APP_SDCARD_STATE_ERROR;
            }
            /* Log successful */
            else
            {
                try = 0;
                SYS_DEBUG_MESSAGE(SYS_ERROR_DEBUG, "Log done ...\r\n");
                appSDcardData.state = APP_SDCARD_STATE_CLOSE;
            }
            break;

        case APP_SDCARD_STATE_CLOSE:
            /* TODO -----> Step #10 */
            /* Try 10 times to close target file */
            if((appSDcardData.FShandle = SYS_FS_FileClose(appSDcardData.FShandle) 
                    != SYS_FS_RES_SUCCESS) && try ++ < 10)
            {
                appSDcardData.state = APP_SDCARD_STATE_CLOSE;
            }
            /* If it fails 10 time raise an error */
            else if(try >= 10)
            {
                SYS_DEBUG_PRINT(SYS_ERROR_DEBUG, 
                        "Closing error : %d\r\n", SYS_FS_Error());
                try = 0;
                appSDcardData.state = APP_SDCARD_STATE_ERROR;
            }
            /* File closed */
            else
            {
                try = 0;
                SYS_DEBUG_MESSAGE(SYS_ERROR_DEBUG, "File closed ...\r\n");
                appSDcardData.state = APP_SDCARD_STATE_UNMOUNT;
            }
            break;
        
        case APP_SDCARD_STATE_UNMOUNT:
            /* TODO -----> Step #11 */
            /* Try up to 10 times to unmount the SD card */
            if((SYS_FS_Unmount(APP_MOUNT_NAME) != SYS_FS_RES_SUCCESS) 
                    && try ++ < 10)
            {
                appSDcardData.state = APP_SDCARD_STATE_UNMOUNT;
            }
            /* If it fails 10 time raise an error */
            else if(try >= 10)
            {
                SYS_DEBUG_PRINT(SYS_ERROR_DEBUG, 
                        "Unmounting error : %d\r\n", SYS_FS_Error());
                try = 0;
                appSDcardData.state = APP_SDCARD_STATE_ERROR;
            }
            /* SD card unmount */
            else
            {
                try = 0;
                SYS_DEBUG_MESSAGE(SYS_ERROR_DEBUG, 
                        "Free to remove SD card\r\n");
                LED_GREEN_Off();
                LED_RED_On();
                appSDcardData.state = APP_SDCARD_STATE_IDLE;
            }
            break;
        
        case APP_SDCARD_STATE_ERROR:
            /* TODO -----> Step #12 */
            LED_RED_Off();
            LED_GREEN_Off();
            SYS_DEBUG_MESSAGE(SYS_ERROR_DEBUG, 
                        "Entering into APP_SDCARD_STATE_ERROR\r\n");
            break;
            
        default:
            break;
    }
}


/*******************************************************************************
 End of File
 */
