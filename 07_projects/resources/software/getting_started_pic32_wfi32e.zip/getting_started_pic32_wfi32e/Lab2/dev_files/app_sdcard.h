/*******************************************************************************
  MPLAB Harmony Application Header File

  Company:
    Microchip Technology Inc.

  File Name:
    app.h

  Summary:
    This header file provides prototypes and definitions for the application.

  Description:
    This header file provides function prototypes and data type definitions for
    the application.  Some of these are required by the system (such as the
    "APP_Initialize" and "APP_Tasks" prototypes) and some of them are only used
    internally by the application (such as the "APP_STATES" definition).  Both
    are defined here for convenience.
*******************************************************************************/

#ifndef _APP_SDCARD_H
#define _APP_SDCARD_H

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "configuration.h"
#include "definitions.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

extern "C" {

#endif
// DOM-IGNORE-END

// *****************************************************************************
// *****************************************************************************
// Section: Type Definitions
// *****************************************************************************
// *****************************************************************************

#define APP_DEV_NAME    "/dev/mmcblka1"
#define APP_MOUNT_NAME  "/mnt/mydrive1"
#define APP_DIR_NAME    "dir1"
#define APP_FILE_NAME   "log.txt"
#define APP_LOG_FILE_PATH   APP_DIR_NAME"/"APP_FILE_NAME
    
#define BUILD_TIME_HOUR     ((__TIME__[0] - '0') * 10 + __TIME__[1] - '0')
#define BUILD_TIME_MIN      ((__TIME__[3] - '0') * 10 + __TIME__[4] - '0')
#define BUILD_TIME_SEC      ((__TIME__[6] - '0') * 10 + __TIME__[7] - '0')

#define LOG_TIME_LEN        10
#define LOG_TEMP_LEN        30
#define LOG_LEN             (LOG_TIME_LEN + LOG_TEMP_LEN)
    
// *****************************************************************************
/* Application states

  Summary:
    Application states enumeration

  Description:
    This enumeration defines the valid application states.  These states
    determine the behavior of the application at various times.
*/

typedef enum
{
    APP_SDCARD_STATE_IDLE,
    APP_SDCARD_STATE_MOUNT,
    APP_SDCARD_STATE_UNMOUNT,
    APP_SDCARD_STATE_OPEN,
    APP_SDCARD_STATE_CLOSE,
    APP_SDCARD_STATE_WRITE,
    APP_SDCARD_STATE_ERROR,

} APP_SDCARD_STATES;


// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    Application strings and buffers are be defined outside this structure.
 */

typedef struct
{
    APP_SDCARD_STATES   state;
    float               temperature;
    bool                isThereSDcard;
    bool                isTemperatureReady;
    SYS_FS_HANDLE       FShandle;

} APP_SDCARD_DATA;

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

void APP_SDCARD_Initialize ( void );
void APP_SDCARD_Tasks( void );

void APP_SDCARD_Notify(float temperature);

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif /* _APP_SDCARD_H */

/*******************************************************************************
 End of File
 */

