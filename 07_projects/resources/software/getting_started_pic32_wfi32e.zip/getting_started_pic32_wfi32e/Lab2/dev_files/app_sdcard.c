/*******************************************************************************
  MPLAB Harmony Application Source File

  Company:
    Microchip Technology Inc.

  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It
    implements the logic of the application's state machine and it may call
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 ******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include "app_sdcard.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

APP_SDCARD_DATA appSDcardData;
uint8_t try = 0;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

void APP_SDCARD_DETECT_EventHandler(GPIO_PIN pin, uintptr_t context)
{
    /* TODO -----> Step #4 */
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

void APP_SDCARD_Notify(float temperature)
{
    /* TODO -----> Step #1 */
}

static inline void APP_BuildLogString(char *log, struct tm time, float temperature)
{
    sprintf(&log[0], "[%02d:%02d:%02d]", time.tm_hour, time.tm_min, time.tm_sec);
    sprintf(&log[LOG_TIME_LEN], " Temperature : %.2f C\r\n", temperature);
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_SDCARD_Initialize ( void )
{
    struct tm sys_time;
    
    /* TODO -----> Step #2a */
	
	/* TODO -----> Step #2b */
	
	/* TODO -----> Step #2c */
	
	/* TODO -----> Step #2d */
    
    /* TODO -----> Step #3a */
	
	/* TODO -----> Step #3b */
    
    /* TODO -----> Step #5 */
    
    /* End of configuration jump in to the first state of your state machine */
    appSDcardData.state = APP_SDCARD_STATE_IDLE;
}


/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_SDCARD_Tasks ( void )
{    
    struct tm sys_time;
    char log_data[LOG_LEN];
    
    /* Check the application's current state. */
    switch ( appSDcardData.state )
    {
        case APP_SDCARD_STATE_IDLE:
            /* TODO -----> Step #6 */
            break;
        
        case APP_SDCARD_STATE_MOUNT:
            /* TODO -----> Step #7 */
            break;
        
        case APP_SDCARD_STATE_OPEN:
            /* TODO -----> Step #8 */
            break;
            
        case APP_SDCARD_STATE_WRITE:
            /* TODO -----> Step #9a */
			
			/* TODO -----> Step #9b */
			
			/* TODO -----> Step #9c */
			
            break;

        case APP_SDCARD_STATE_CLOSE:
            /* TODO -----> Step #10 */
            break;
        
        case APP_SDCARD_STATE_UNMOUNT:
            /* TODO -----> Step #11 */
            break;
        
        case APP_SDCARD_STATE_ERROR:
            /* TODO -----> Step #12 */
            break;
			
        default:
            break;
    }
}


/*******************************************************************************
 End of File
 */
