/*******************************************************************************
* Copyright (C) 2020 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/

/*******************************************************************************
  MPLAB Harmony Application Header File

  Company:
    Microchip Technology Inc.

  File Name:
    app.h

  Summary:
    This header file provides prototypes and definitions for the application.

  Description:
    This header file provides function prototypes and data type definitions for
    the application.  Some of these are required by the system (such as the
    "APP_Initialize" and "APP_Tasks" prototypes) and some of them are only used
    internally by the application (such as the "APP_STATES" definition).  Both
    are defined here for convenience.
*******************************************************************************/

#ifndef _APP_SENSOR_H
#define _APP_SENSOR_H

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "configuration.h"
#include "definitions.h"
#include "system/console/sys_console.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility

extern "C" {

#endif
// DOM-IGNORE-END

// *****************************************************************************
// *****************************************************************************
// Section: Includes
// *****************************************************************************
// *****************************************************************************    
    
#define TEMP_SENSOR_READ_TEMP_REG   0x00
#define TEMP_SENSOR_CONFIG_REG      0x01

#define TEMP_SENSOR_BASE_ADDRESS    0x09
#define I2C1_A0_PULL                UP
#define I2C1_A1_PULL                UP
#define I2C1_A2_PULL                UP

// *****************************************************************************
// *****************************************************************************
// Section: Type Definitions
// *****************************************************************************
// *****************************************************************************

typedef enum
{
    DOWN = 0,
    UP = 1,
} PULL;

// *****************************************************************************

typedef enum
{
    APP_SENSOR_STATE_WAIT_USB_CONSOLE_CONFIGURED = 0,
    APP_SENSOR_STATE_GET_CONSOLE_HANDLE,
    APP_SENSOR_STATE_IDLE,
    APP_SENSOR_STATE_I2C_READ_TASKS,
    APP_SENSOR_STATE_USB_PRINT,
    APP_SENSOR_STATE_ERROR,
} APP_SENSOR_STATES;


// *****************************************************************************

typedef struct
{
    uint16_t address;
    uint8_t id;
    uint8_t temp_reg;
    uint8_t config_reg;
    
} APP_I2C_TEMP_SENSOR_INFO;

// *****************************************************************************

typedef struct
{
    float                       lastValueRead;
    APP_I2C_TEMP_SENSOR_INFO    sensor;
    DRV_HANDLE                  instance;
    uint8_t                     i2cRxBuffer[3];    
    uint8_t                     i2cTxBuffer[3];
    DRV_I2C_TRANSFER_HANDLE     i2cTransferHandle;

} APP_I2C_TEMP_SENSOR_DATA;

// *****************************************************************************

typedef struct
{
    
    bool                        tmrExpired;
    bool                        isLogEnable;
    bool                        isTransferDone;
    APP_SENSOR_STATES           state;
    APP_I2C_TEMP_SENSOR_DATA    i2c;
    SYS_CONSOLE_HANDLE          console0Handle;
} APP_SENSOR_DATA;

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

void APP_SENSOR_Initialize ( void );
void APP_SENSOR_Tasks( void );

#endif /* _APP_SENSOR_H */

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

/*******************************************************************************
 End of File
 */

