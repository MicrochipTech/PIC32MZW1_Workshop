/*******************************************************************************
* Copyright (C) 2020 Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/

/*******************************************************************************
  MPLAB Harmony Application Source File

  Company:
    Microchip Technology Inc.

  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It
    implements the logic of the application's state machine and it may call
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 ******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include "app_sensor.h"
#include "configuration.h"
#include "system/debug/sys_debug.h"
#include "system/console/sys_console.h"
#include "bsp/bsp.h"
#include "definitions.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

APP_SENSOR_DATA             appSensorData;
DRV_I2C_TRANSFER_HANDLE     i2c1TransferHandle;
uint16_t                    tmp;

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

static void APP_I2C_EventHandler(
    DRV_I2C_TRANSFER_EVENT event,
    DRV_I2C_TRANSFER_HANDLE transferHandle,
    uintptr_t context
)
{
    /* TODO -----> Step #3 */
    switch(event)
    {
		case DRV_I2C_TRANSFER_EVENT_COMPLETE:

            break;
        case DRV_I2C_TRANSFER_EVENT_ERROR:

            break;
        default:
            break;
    }
}

static void APP_SWITCH_EventHandler(GPIO_PIN pin, uintptr_t context)
{
    if(SWITCH1_Get() == SWITCH1_STATE_PRESSED)
    {
        /* TODO -----> Step #7 */
    }
}

static void SYS_TIME_EventHandler(uintptr_t context)
{
    /* TODO -----> Step #9 */
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

DRV_I2C_ERROR APP_I2C_TempRead(void)
{
    DRV_I2C_ERROR error;
    
    /* TODO -----> Step #5a */
    
	/* TODO -----> Step #5b */
	
    return error;
}

// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

void APP_SENSOR_Initialize ( void )
{    
    /* TODO -----> Step #1 */
   
    /* TODO -----> Step #2 */
    
    /* TODO -----> Step #4a */
    
    /* TODO -----> Step #4b */
    //appSensorData.i2c.sensor.temp_reg     = TEMP_SENSOR_READ_TEMP_REG;
    //appSensorData.i2c.sensor.config_reg   = TEMP_SENSOR_CONFIG_REG;
    
    /* TODO -----> Step #6a */
	
	/* TODO -----> Step #6b */
    
    /* TODO -----> Step #8 */
    
    appSensorData.i2c.i2cTransferHandle   = i2c1TransferHandle;
    
    /* End of configuration jump in to the first state of your state machine */
    appSensorData.state = APP_SENSOR_STATE_WAIT_USB_CONSOLE_CONFIGURED;
}

/******************************************************************************/

void APP_SENSOR_Tasks ( void )
{
    switch ( appSensorData.state )
    {
        case APP_SENSOR_STATE_WAIT_USB_CONSOLE_CONFIGURED:
            /* Wait for the console ready */
            /* This is mandatory to guarantee the correct functioning 
                                                            of the USB driver */
            if (SYS_DEBUG_Status(SYS_CONSOLE_INDEX_0) == SYS_STATUS_READY)
            {
                /* Switch to idle */
                appSensorData.state = APP_SENSOR_STATE_IDLE;
            }
            break;
            
        case APP_SENSOR_STATE_IDLE:
            /* TODO -----> Step #10a */
            break ;
            
        case APP_SENSOR_STATE_I2C_READ_TASKS:
            /* TODO -----> Step #10b */
            break ;
            
        case APP_SENSOR_STATE_USB_PRINT :
            /* TODO -----> Step #10c */
            break;
            
        case APP_SENSOR_STATE_ERROR:
            /* TODO -----> Step #10d */
        default:
            break;

    }
}

/*******************************************************************************
 End of File
 */
